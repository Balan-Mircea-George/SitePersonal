function RobotForm() {
  return (
 <div role="form" id="send-comment" aria-label="Robot form">
 <p id="sarmale">/test/</p>
  <p>Robot&nbsp;form</p>
  <label htmlFor="name">Name</label>
  <input
    id="name"
    name="name"
    type="text" />

  <label htmlFor="type">Type</label>
  <input
    id="type"
    name="type"
    type="text" />
	
 <label htmlFor="mass">Mass</label>
  <input
    id="mass"
    name="mass"
    type="text" />


  <label htmlFor="comment">Comment</label>
  <textarea id="comment" name="comment"></textarea>

  <input value="Comment" type="submit" />

</div>

  )
  
}
export default RobotForm
