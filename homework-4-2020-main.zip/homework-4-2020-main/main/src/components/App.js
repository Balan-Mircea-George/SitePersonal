import RobotList from './RobotList'
import RobotForm from './RobotForm'

function App () {
  return (
      <div>
      	<p>A-list-of-robots</p>
      	<RobotList />
		<RobotForm />
      </div>
  )
}

export default App
