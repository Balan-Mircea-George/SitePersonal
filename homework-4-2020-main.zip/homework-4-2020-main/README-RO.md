# Instrucțiuni de rulare

# Obiectiv : Să se modifice în locul marcat fișierul JS astfel încât să treacă testele

# Pași pentru a rula testele și a trimite tema
1. Clonați repository-ul cu tema
2. Din directorul `main` rulați `npm install`
3. Din directorul `main` rulați `npm test`
4. Ștergeți directorul node_modules
5. Arhivați directorul cu rezolvare ca zip
6. Încărcați arhiva prin intermediul formularului